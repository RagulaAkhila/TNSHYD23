package approach2;

import approach1.Demo;

public class C {
	
	public static void main(String[] args) {
		Demo b1=new Demo();
		System.out.println("b1.b");
		b1.display();
		System.out.println("Demo.c");
		Demo.display();
	}

}
