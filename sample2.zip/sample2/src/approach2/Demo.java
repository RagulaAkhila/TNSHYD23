package approach2;

public class Demo {

	int b=20;
	static int c=30;
	int display()
	{
		return 20;
	}
	static void space()
	{
		System.out.println("10");
	}
}
