package protected1;

public class p1 {
	
		protected void display() {
			System.out.println("access protected specifier");
		}

	}



