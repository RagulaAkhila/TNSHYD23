package userdefined;

public class p1 {
	public void display()
	{
		System.out.println("userdefined");
	}
	}


