package approach1;


public class Demo {
	int b=20;
	static int c=30;
	int display1()
	{
		return(10);
	}
	public static void display()
	{
System.out.println(10);
	}
	public static void main(String args[])
	{
		Demo obj=new Demo();
		System.out.println(obj.b);
		obj.display();
		System.out.println(Demo.c);
		Demo.display();
	}
	
	}


