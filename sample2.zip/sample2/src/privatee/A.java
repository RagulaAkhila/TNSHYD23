package privatee;

import privatee.A;

public class A {
	private void display()

	{
		System.out.println("Tns sessions");
	}
	public static void main(String[] args) {
		A obj=new A();
		obj.display();
	}
}


