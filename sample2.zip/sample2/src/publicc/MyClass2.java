package publicc;

public class MyClass2 {

	public static void main(String[] args) {
		MyClass1 obj=new MyClass1();
		obj.display();
	}

}

	


