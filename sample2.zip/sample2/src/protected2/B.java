package protected2;

import protected1.*;

public class B  extends p1 {

	public static void main(String[] args) {
	     B obj=new B();
        	obj.display();

	}

}


