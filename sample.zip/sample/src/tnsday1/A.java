package tnsday1;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("well come to tns:");

	}

}
